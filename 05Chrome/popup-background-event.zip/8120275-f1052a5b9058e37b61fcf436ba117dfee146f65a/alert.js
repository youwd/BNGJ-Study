alert('hello ' + document.location.href);
